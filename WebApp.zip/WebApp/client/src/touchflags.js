export const TouchFlags =
{
  IndirectTouch: 1 << 0,
  PrimaryTouch: 1 << 4,
  Tap: 1 << 5,
  OrphanedPrimaryTouch: 1 << 6,
};
